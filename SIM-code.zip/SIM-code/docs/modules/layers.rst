fastreid.layers
=========================

.. automodule:: fastreid.layers
    :members:
    :undoc-members:
    :show-inheritance:
