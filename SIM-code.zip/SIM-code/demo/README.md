# FastReID Demo

We provide a command line tool to run a simple demo of builtin models.

You can run this command to get cosine similarites between different images 

```bash
cd demo/
sh run_demo.sh
```